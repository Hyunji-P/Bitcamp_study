package aopexam.sample02;

public class DataBase {

	public static void save(String msg) {
		System.out.println( msg + " 내역을 데이터 베이스에 저장합니다.");
	}
}