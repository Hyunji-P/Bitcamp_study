package aopexam.sample04;

public interface Order {
	public void order();  //  주문하기
}