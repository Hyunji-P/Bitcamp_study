package aopexam.sample04;

public interface Board {
	public void board();
}