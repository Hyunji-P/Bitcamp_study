package aopexam.sample03;

public interface Board {
	public void board() ; //게시물 등록 하기
}