package aopexam.sample03;

public class Logout{	
	public void logout() {
		System.out.println( "로그 아웃을 수행합니다." );		
	}
}