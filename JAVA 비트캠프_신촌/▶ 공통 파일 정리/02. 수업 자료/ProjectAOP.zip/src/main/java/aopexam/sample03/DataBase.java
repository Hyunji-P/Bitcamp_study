package aopexam.sample03;

public class DataBase {
	public void dao(){
		System.out.println("데이터 베이스 작업을 수행합니다.");
	}
}