package rectangle.exam;

public interface Rectangle {
	public void Print();
	public void Diagonal();
}