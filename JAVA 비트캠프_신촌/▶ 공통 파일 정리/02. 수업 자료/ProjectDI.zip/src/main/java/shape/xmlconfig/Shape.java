package shape.xmlconfig;
import java.util.List;
public interface Shape {
	public Object getProductOne() ; // 1개의 정보
	public List<Object> getAllProducts() ;// 모든 목록 가져오기
}