package coupling;

public class BaseballBackup {
    public void play() {
        System.out.println("야구 게임을 합니다.");
    }
    public void stop() {
        System.out.println("야구 게임을 중지합니다.");
    }    
}