package coupling;

public interface Sport {
    void play();
    void stop();
}