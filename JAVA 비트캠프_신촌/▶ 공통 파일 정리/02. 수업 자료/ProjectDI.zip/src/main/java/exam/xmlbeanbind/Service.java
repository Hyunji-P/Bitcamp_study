package exam.xmlbeanbind;

public interface Service {
	void order(); //주문 배송 접수 받기
	void cancel(); //주문 배송 취소 하기
}