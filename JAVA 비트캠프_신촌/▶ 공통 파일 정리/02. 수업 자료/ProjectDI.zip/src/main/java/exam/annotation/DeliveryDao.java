package exam.annotation;

public interface DeliveryDao {
	void insertAddress() ; //배송지 추가
	void removeAddress() ; //배송지 삭제
}