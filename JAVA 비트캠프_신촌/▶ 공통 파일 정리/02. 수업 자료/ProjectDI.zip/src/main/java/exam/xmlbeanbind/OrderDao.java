package exam.xmlbeanbind;

public interface OrderDao {
	void insertOrder(); //주문 정보 추가
	void removeOrder(); //주문 정보 삭제
}