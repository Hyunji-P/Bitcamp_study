package mypkg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectDiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectDiApplication.class, args);
	}

}
