package play.instrument;

public class Guitar implements Instrument{
	public void play() {
		System.out.println("��Ÿ ����");		
	}
}