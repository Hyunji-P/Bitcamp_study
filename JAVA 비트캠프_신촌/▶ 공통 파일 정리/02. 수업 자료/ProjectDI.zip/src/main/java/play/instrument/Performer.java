package play.instrument;

public interface Performer {
	void perform() ;
}