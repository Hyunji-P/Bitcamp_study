package play.instrument;

public class Harmonica implements Instrument{
	public void play() {
		System.out.println("�ϸ��ī ����");		
	}
}