package play.instrument;

public class Piano implements Instrument {
	public void play() {
		System.out.println("�ǾƳ븦 ġ��");		
	}
}