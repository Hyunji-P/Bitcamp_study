package mypkg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectMybatisApplication.class, args);
	}

}
