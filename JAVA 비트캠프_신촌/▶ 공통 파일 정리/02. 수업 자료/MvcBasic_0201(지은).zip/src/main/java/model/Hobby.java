package model;

//��̸� �����ϱ� ���� Ŭ����
public class Hobby {
	private String english ; //���� �̸�
	private String korea ; //���� �̸�
	
	
	public String getEnglish() {
		return english;
	}
	public void setEnglish(String english) {
		this.english = english;
	}
	public String getkorea() {
		return korea;
	}
	
	public void setkorea(String korea) {
		this.korea = korea;
	}
	@Override
	public String toString() {
		return "Hobby [english=" + english + ", korea=" + korea + "]";
	}
	
	public Hobby(String english, String korea) {
		super();
		this.english = english;
		this.korea = korea;
	}

	
}
