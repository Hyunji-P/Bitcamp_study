package premiumPjt;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Premium {
	private String ID; // ���� ID
	private String name; // ���� ����
	private String birth;// �������
	private String contractDate; // ��� ����
	private String depositDate;// �Ա� ����
	private String depositMonth; // �Ա� ����
	private String depositNumber;// �Ա� ȸ��
	private int premium; // �� �����
	private int v_premium;// ������·� �Ա��� �����
	private String VirtualAccount; // ������¹�ȣ
	private String bank; // �����

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getContractDate() {
		return contractDate;
	}

	public void setContractDate(String contractDate) {
		this.contractDate = contractDate;
	}

	public String sublist() {
		return depositDate;
	}

	public void setDepositDate(String depositDate) {
		this.depositDate = depositDate;
	}

	public String getDepositMonth() {
		return depositMonth;
	}

	public void setDepositMonth(String depositMonth) {
		this.depositMonth = depositMonth;
	}

	public String getDepositNumber() {
		return depositNumber;
	}

	public void setDepositNumber(String depositNumber) {
		this.depositNumber = depositNumber;
	}

	public int getPremium() {
		return premium;
	}

	public void setPremium(int premium) {
		this.premium = premium;
	}

	public int getV_premium() {
		return v_premium;
	}

	public void setV_premium(int v_premium) {
		this.v_premium = v_premium;
	}

	public String getVirtualAccount() {
		return VirtualAccount;
	}

	public void setVirtualAccount(String virtualAccount) {
		VirtualAccount = virtualAccount;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getDepositDate() {

		return depositDate;
	}

}
